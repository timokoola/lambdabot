line1 = "5guoyjTaAR9tKaTHM9iGiL3pH"
line2 = "A2w4oMG2HR6xv9EsNN7g7UxnusM7CNt4VKAnWKmpaO3XS1Vu93"
line3 = "4692197935-wnIzbglMjWYI5ObxcHX6GecwZkN1GvqoAnzUKis"
line4 = "cgED0QQgRInuVa5F32OtUyY87zud7jdLzH16cun1Jv0vl"